#!/bin/bash

# Business3 快速部署脚本

echo "🚀 开始部署Business3业务包..."

# 检查是否在React Native项目根目录
if [ ! -d "android/app/src/main" ]; then
    echo "❌ 请在React Native项目根目录运行此脚本"
    exit 1
fi

# 创建必要目录
echo "📁 创建目录..."
mkdir -p android/app/src/main/assets
mkdir -p android/app/src/main/res/drawable-mdpi
mkdir -p android/app/src/main/res/drawable-hdpi
mkdir -p android/app/src/main/res/drawable-xhdpi
mkdir -p android/app/src/main/res/drawable-xxhdpi
mkdir -p android/app/src/main/res/drawable-xxxhdpi

# 部署Bundle文件
echo "📦 部署Bundle文件..."
if [ -f "business3.android.bundle" ]; then
    cp business3.android.bundle android/app/src/main/assets/
    echo "  ✅ Bundle文件已部署"
else
    echo "  ❌ 找不到Bundle文件: business3.android.bundle"
    exit 1
fi

# 部署图片资源
echo "🖼️ 部署图片资源..."
DRAWABLE_DIRS=("drawable-mdpi" "drawable-hdpi" "drawable-xhdpi" "drawable-xxhdpi" "drawable-xxxhdpi")

for drawable_dir in "${DRAWABLE_DIRS[@]}"; do
    if [ -d "$drawable_dir" ] && [ "$(ls -A $drawable_dir 2>/dev/null)" ]; then
        cp "$drawable_dir"/*.png "android/app/src/main/res/$drawable_dir/" 2>/dev/null || true
        file_count=$(ls "$drawable_dir"/*.png 2>/dev/null | wc -l)
        echo "  ✅ $drawable_dir: $file_count 个文件已部署"
    else
        echo "  ⚠️ $drawable_dir 目录为空或不存在"
    fi
done

echo ""
echo "🎉 Business3业务包部署完成！"
echo ""
echo "📋 后续步骤："
echo "1. 重新构建Android应用: cd android && ./gradlew assembleDebug"
echo "2. 安装并运行应用"
echo "3. 点击 '🖼️ 业务包 3' 按钮测试功能"
